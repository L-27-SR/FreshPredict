import React, { useState, useEffect, useCallback } from 'react';
import { Upload } from 'lucide-react';

interface Prediction {
  className: string;
  probability: number;
}

const MODEL_URL = "https://teachablemachine.withgoogle.com/models/K7blBiEO9/";

export default function ImageClassifier() {
  const [model, setModel] = useState<any>(null);
  const [imageUrl, setImageUrl] = useState<string>('');
  const [predictions, setPredictions] = useState<Prediction[]>([]);
  const [isLoading, setIsLoading] = useState(false);

  // Load the model on component mount
  useEffect(() => {
    loadModel();
  }, []);

  const loadModel = async () => {
    try {
      const modelURL = MODEL_URL + "model.json";
      const metadataURL = MODEL_URL + "metadata.json";
      const loadedModel = await window.tmImage.load(modelURL, metadataURL);
      setModel(loadedModel);
    } catch (error) {
      console.error('Failed to load model:', error);
    }
  };

  const handleImageUpload = useCallback(async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file || !model) return;

    try {
      setIsLoading(true);
      // Create image URL for preview
      const url = URL.createObjectURL(file);
      setImageUrl(url);

      // Create an image element for prediction
      const img = new Image();
      img.src = url;
      await img.decode(); // Ensure image is loaded

      // Make prediction
      const predictions = await model.predict(img);
      setPredictions(predictions);
    } catch (error) {
      console.error('Error processing image:', error);
    } finally {
      setIsLoading(false);
    }
  }, [model]);

  return (
    <div className="max-w-2xl mx-auto p-6 space-y-6">
      <div className="text-center">
        <h1 className="text-3xl font-bold text-gray-900 mb-2">Image Classifier</h1>
        <p className="text-gray-600">Upload an image to classify it using the trained model</p>
      </div>

      <div className="border-2 border-dashed border-gray-300 rounded-lg p-8 text-center">
        <input
          type="file"
          accept="image/*"
          onChange={handleImageUpload}
          className="hidden"
          id="image-upload"
        />
        <label
          htmlFor="image-upload"
          className="flex flex-col items-center justify-center cursor-pointer"
        >
          <Upload className="w-12 h-12 text-gray-400 mb-3" />
          <span className="text-gray-600">Click to upload an image</span>
        </label>
      </div>

      {imageUrl && (
        <div className="mt-6">
          <div className="relative w-full max-w-md mx-auto aspect-square rounded-lg overflow-hidden">
            <img
              src={imageUrl}
              alt="Uploaded"
              className="object-cover w-full h-full"
            />
          </div>
        </div>
      )}

      {isLoading && (
        <div className="text-center py-4">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-gray-900 mx-auto"></div>
        </div>
      )}

      {predictions.length > 0 && (
        <div className="bg-white rounded-lg shadow p-6">
          <h2 className="text-xl font-semibold mb-4">Predictions</h2>
          <div className="space-y-3">
            {predictions.map((prediction, index) => (
              <div key={index} className="flex justify-between items-center">
                <span className="text-gray-700">{prediction.className}</span>
                <div className="flex items-center">
                  <div className="w-48 bg-gray-200 rounded-full h-2.5 mr-2">
                    <div
                      className="bg-blue-600 h-2.5 rounded-full"
                      style={{ width: `${prediction.probability * 100}%` }}
                    ></div>
                  </div>
                  <span className="text-sm text-gray-600">
                    {(prediction.probability * 100).toFixed(1)}%
                  </span>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}